<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Contracts\Service\Attribute\Required;
use App\Models\allowed;
use App\Models\admin;
use App\Models\products;
use Session;
use Hash;
use App\Jobs\mailjob;

class auth extends Controller
{
    public function insert(Request $request)
    {
        $request->validate(
            [
                "username" => 'required',
                "email" => 'required|email|unique:alloweds',
                "password" => 'required',
                "cpass" => 'required'

            ]
        );

        $user = new allowed();
        $user->username = $request->username;
        $user->email = $request->email;
        $user->password = Hash::make($request->password); //encrypt password
        $res = $user->save();

        if ($res) {
            return back()->with('success', 'You have Registered Successfully');
        } else {
            return back()->with('failed', 'Registration failed');
        }

    }


    public function logincheck(Request $request)
    {
        $request->validate(
            [
                "email" => 'required|email',
                "password" => 'required',
            ]
        );

        $user = allowed::where('email', '=', $request->email)->first();
        if ($user) {
            if (Hash::check($request->password, $user->password)) {
                $request->session()->put('loginid', $user->id);
                return redirect('home');

            } else {
                return back()->with('failed', 'password is wrong');
            }

        } else {
            return back()->with('failed', 'email doesnt exists');
        }







    }
    public function resetpassword(Request $request)
    {
        $request->validate(
            [
                "email" => 'required|email',

            ]
        );
        $usermail = DB::table('alloweds')->where(['email' => $request->email])->first();
        if ($usermail) {
            $password = Hash::make(1234567);
            DB::table('alloweds')->update([
                'password' => $password

            ]);
            dispatch(new mailjob($usermail));
            return view('login');
        } else {
            return back()->with('failed', 'email doesnt exists');
        }




    }

    public function cinfo(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'pnumber' => 'required',
            'message' => 'required'


        ]);


        DB::table('contactinfo')->insert(
            [
                'name' => $request->input('name'),
                'email' => $request->input('email'),
                'pnumber' => $request->input('pnumber'),
                'message' => $request->input('message')


            ]
        );
        if (true) {
            return back()->with('success', 'your message has been sent successfully');
        } elseif (false) {
            return back()->with('failed', ' We were not able to sent your message');
        }
    }



    public function adminlogin(Request $request)
    {
        $request->validate(
            [
                "email" => 'required|email',
                "password" => 'required',
            ]
        );

        $admin = admin::where('email', '=', $request->email)->first();
        if ($admin) {
            if (Hash::check($request->password, $admin->password)) {
                $request->session()->put('loginid', $admin->id);
                return redirect('dashboard');

            } else {
                return back()->with('failed', 'password is wrong');
            }

        } else {
            return back()->with('failed', 'email doesnt exists');
        }


    }

    public function insertbook(Request $request)
    {


        $books = new products;
        $books->id = $request->input('id');
        $books->book_name = $request->input('book_name');
        $books->book_desc = $request->input('book_desc');
        $books->book_cat = $request->input('book_cat');
        $books->book_author = $request->input('book_author');
        $books->price = $request->input('price');

        if ($request->hasfile('image')) {
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/books/', $filename);
            $books->image = $filename;

        }
        $books->save();



        // DB::table('products')->insert([
        //     'id'=>$request->id,
        //     'book_name'=>$request->book_name,
        //     'book_desc'=>$request->book_desc,
        //     'book_cat'=>$request->book_cat,
        //     'book_author'=>$request->book_author,
        //     'price'=>$request->price,
        //     'image'=>$request->image,

        // ]);



        if (true) {
            return back()->with('success', 'You have entered  Successfully');


        } else if (false) {
            return back()->with('failed', 'entry failed');
        }
    }


    public function addcart($id)
    {
        $product=products::findorfail();
        $cart=session()->get('cart',[]);

    }


}
