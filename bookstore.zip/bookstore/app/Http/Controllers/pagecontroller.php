<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Migrations;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use Session;

class pagecontroller extends Controller
{

    public function landingpage()
    {
        return view('login');
    }
    public function login()
    {
        return view('login');
    }


    public function signup()
    {
        return view('signup');
    }

    public function home()
    {
        $products=DB::table('products')->get();
        return view('home',['products'=>$products]);

    }

    public function logout()
    {
        if(Session::has('loginid'))//checking the session
        {
            session::pull('loginid');//destroying the session
            return view('login');
        }

    }

    public function forgotpassword()
    {
        return view('forgotpassword');
    }

    public function contactus()
    {
        return view('contactus');
    }

    public function aboutus()
    {
        return view('aboutus');
    }

    public function allbooks()
    {
        $products=DB::table('products')->get();
        return view('allbooks',['products'=>$products]);

    }

    public function adminportal()
    {
        return view('adminportal');
    }

    public function dashboard()
    {
        $products=DB::table('products')->get();
        return view('dashboard',['products'=>$products]);
    }

    public function alogout()
    {
        if(Session::has('loginid'))//checking the session
        {
            session::pull('loginid');//destroying the session
            return view('adminportal');
        }

    }

    public function ainsert()
    {
        return view('insertbook');
    }

    public function cataction()
    {
        $products=DB::table('products')->where('book_cat','Action')->get();
        return view('allbooks',['products'=>$products]);
    }

    public function cathorror()
    {
        $products=DB::table('products')->where('book_cat','Horror')->get();
        return view('allbooks',['products'=>$products]);
    }

    public function catthriller()
    {
        $products=DB::table('products')->where('book_cat','Thriller')->get();
        return view('allbooks',['products'=>$products]);
    }

    public function catfantasy()
    {
        $products=DB::table('products')->where('book_cat','Fantasy')->get();
        return view('allbooks',['products'=>$products]);
    }

    public function catromance()
    {
        $products=DB::table('products')->where('book_cat','Romance')->get();
        return view('allbooks',['products'=>$products]);
    }

    public function catmystery()
    {
        $products=DB::table('products')->where('book_cat','Mystery')->get();
        return view('allbooks',['products'=>$products]);
    }

}
