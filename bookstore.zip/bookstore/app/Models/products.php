<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class products extends Model
{
  protected $table='products';
  protected $fillable=["id","book_name","book_desc","book_cat","book_author","price","image"];
    use HasFactory;
}
