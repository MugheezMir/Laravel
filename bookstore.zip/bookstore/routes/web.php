<?php
use App\Http\Controllers\pagecontroller;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

route::get('/',[pagecontroller::class,'landingpage']);
route::get('/login',[pagecontroller::class,'login']);
route::post('logincheck',[auth::class,'logincheck']);
route::get('/signup',[pagecontroller::class,'signup']);
route::post('insert', [auth::class, 'insert']);
route::get('/home',[pagecontroller::class,'home'])->middleware('loggedin');
route::get('/logout',[pagecontroller::class,'logout']);
route::get('/forgotpassword',[pagecontroller::class,'forgotpassword']);
route::post('/resetpassword',[auth::class,'resetpassword']);
route::get('/contactus',[pagecontroller::class,'contactus'])->middleware('loggedin');
route::post('cinfo',[auth::class,'cinfo']);
route::get('/aboutus',[pagecontroller::class,'aboutus'])->middleware('loggedin');
route::get('/allbooks',[pagecontroller::class,'allbooks'])->middleware('loggedin');
route::get('/dashboard',[pagecontroller::class,'dashboard'])->middleware('adminscheck');
route::get('/auth/adminsportal',[pagecontroller::class,'adminportal']);
route::post('/auth/adminlogin',[auth::class,'adminlogin']);
route::get('/adminlogout',[pagecontroller::class,'alogout']);
route::get('/auth/admin/insert',[pagecontroller::class,'ainsert']);
route::post('/auth/admin/insertbook',[auth::class,'insertbook']);
route::get('/addtocart/{id}',[auth::class,'addcart'])->name('addtocart');
route::get('auth/admin/update{id}',[pagecontroller::class,'update']);
route::get('/action',[pagecontroller::class,'cataction']);
route::get('/horror',[pagecontroller::class,'cathorror']);
route::get('/romance',[pagecontroller::class,'catromance']);
route::get('/thriller',[pagecontroller::class,'catthriller']);
route::get('/fantasy',[pagecontroller::class,'catfantasy']);
route::get('/mystery',[pagecontroller::class,'catmystery']);
