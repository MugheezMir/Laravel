@include('layout.master')

    <div>
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13615.23964550655!2d74.2682316!3d31.4468997!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3919017432b1835b%3A0xe396992a5b05891c!2sUniversity%20of%20Central%20Punjab!5e0!3m2!1sen!2s!4v1681971215292!5m2!1sen!2s"  style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <div class="container contact-form">
        <div class="contact-image">
            <img src="open-book.png" alt="error loading picture"/>
        </div>
        <form action="cinfo" method="POST">
            <h3>Drop Us a Message</h3>
           <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        @csrf
                        @if (Session::has('success'))
                        <div class="alert alert-success">{{ session::get('success') }}</div>
                        @endif
                        @if (Session::has('failed'))
                        <div class="alert alert-success">{{ session::get('success') }}</div>
                        @endif
                        <input type="text" name="name" class="form-control" placeholder="Your Name "value="{{ old('email') }}" >
                        <span style="color:red">@error ('name'){{ $message }} @enderror</span>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="text" name="email" class="form-control" placeholder="Your Email " value="{{ old('email') }}"  >
                        <span style="color:blue">@error ('name'){{ $message }} @enderror</span>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="text" name="pnumber" class="form-control" placeholder="Your Phone Number " value="{{ old('email') }}" >
                        <span style="color:red">@error ('name'){{ $message }} @enderror</span>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="submit" name="submit" class="btnContact" value="Send Message" >
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <textarea name="message" class="form-control" placeholder="Your Message *" style="width: 100%; height: 150px; "value="{{ old('email') }}"></textarea>
                        <span style="color:red">@error ('name'){{ $message }} @enderror</span>
                    </div>
                </div>
            </div>
        </form>
</div>

@include('layout.footer')
