{{-- @include('layout.master') --}}
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css.css">
    <script src="https://kit.fontawesome.com/522294af6f.js" crossorigin="anonymous"></script>
  </head>
  <body>

  <div>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark p-3">
    <div class="container-fluid">
      <a class="navbar-brand sides" href="/home">BookHive</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class=" collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto ">
          <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="/home">Home</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Category
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="/action">Action</a></li>
              <li><a class="dropdown-item" href="/horror">Horror</a></li>
              <li><a class="dropdown-item" href="/romance">Romance</a></li>
              <li><a class="dropdown-item" href="/thriller">Thriller</a></li>
              <li><a class="dropdown-item" href="/fantasy">Fantasy</a></li>
              <li><a class="dropdown-item" href="/mystery">Mystery</a></li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Info
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="/aboutus">About Us</a></li>
              <li><a class="dropdown-item" href="/contactus">Contact us</a></li>
            </ul>
          </li>
         <li class="dropdown">
            <button type="button" class="btn btn-primary" data-toggle="dropdown">
               <i class="fa fa-shopping-cart" aria-hidden="true"></i>Cart <span class="badge badge-pill badge-danger"></span>
            </button>

         </li>
          <li class="nav-item">
            <a class="nav-link mx-2" href="/logout">Logout</a>
          </li>
        </ul>
      </div>
    </div>
</div>
        {{-- @yield('content') --}}


    </body>
    </html>



<section style="background-color: #eee;">
    <div class="container py-5">
        <div class="row justify-content-center mb-3">

            @foreach ($products as $product)
                <div class="col-md-12 col-xl-10">
                    <div class="card shadow-0 border rounded-3">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 col-lg-3 col-xl-3 mb-4 mb-lg-0">
                                    <div class="bg-image hover-zoom ripple rounded ripple-surface">
                                        <img src="{{ asset('uploads/books/' . $product->image) }}" class="w-100" />
                                        <a href="#!">
                                            <div class="hover-overlay">
                                                <div class="mask"
                                                    style="background-color: rgba(253, 253, 253, 0.15);"></div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-xl-6">
                                    <h5 class="mb-1 me-1">Title: {{ $product->book_name }}</h5>
                                    <div class="d-flex flex-row">

                                    </div>
                                    <div class="mt-1 mb-0 text-muted medium">
                                        <span>Author: {{ $product->book_author }}</span>
                                        <span class="text-primary"> • </span>
                                        <span>Catagory: {{ $product->book_cat }}</span>

                                    </div>
                                    <br>
                                    <h3 class="mb-1 me-1">
                                        Description</h3>
                                    <p>{{ $product->book_desc }}</p>
                                </div>
                                <div class="col-md-6 col-lg-3 col-xl-3 border-sm-start-none border-start">
                                    <div class="d-flex flex-row align-items-center mb-1">
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                        <h4 class="mb-1 me-1"> Price: ${{ $product->price }}</h4>

                                    </div>

                                    <div class="d-flex flex-column mt-4">

                                        <button class="btn btn-primary btn-sm" type="button">Details</button>
                                        <button class="btn btn-outline-primary btn-sm mt-2" type="button"><a
                                                href={{ route('addtocart', $product->id) }}>Add to Cart</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@include('layout.footer');
