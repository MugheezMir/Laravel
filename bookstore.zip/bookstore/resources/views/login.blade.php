<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <script src="https://kit.fontawesome.com/522294af6f.js" crossorigin="anonymous"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <link rel="stylesheet" href="css.css">
  <title>Log in</title>
</head>
<body>
<div class="container-fluid">
  <video autoplay muted loop id="myVideo">
    <source src="you1.mp4" type="video/mp4">
  </video>
  </div>
  <div class="container-fluid h-100">
    <div class="w-100 p-5">
    <div class="row align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5 mx-auto">
        <div class="card bg-dark text-white">
          <div class="card-body p-5 text-center">
            <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
            <p class="text-white-50 mb-5">Please enter your login and password!</p>

            <form action="logincheck" method="Post">
              @csrf
              @if (Session::has('failed'))
                        <div class="alert alert-s=danger" style="color:red">{{ session::get('failed') }}</div>

                        @endif
              <div class="form-outline form-white mb-4">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control form-control-lg" value="{{ old('email') }}">
                <span style="color:blue">@error ('username'){{ $message }} @enderror</span>
              </div>

              <div class="form-outline form-white mb-4">
                <i class="fa-solid fa-lock"></i>
                <label class="form-label" >Password</label>
                <input type="password" name="password" class="form-control form-control-lg" />
                <span style="color: red">@error ('password'){{ $message }} @enderror</span>
              </div>

              <p class="small mb-5 pb-lg-2"><a class="text-white-50" href="/forgotpassword">Forgot password?</a></p>

              <button class="btn btn-outline-light btn-lg px-5" type="submit"><i class="fa-solid fa-book fa-sm"></i></button>
            </form>

            <div class="d-flex justify-content-center text-center mt-4 pt-1">
              <a href="https://www.facebook.com/" class="text-white" target="_blank"><i class="fab fa-facebook-f fa-lg"></i></a>
              <a href="https://twitter.com/?lang=en" class="text-white" target="_blank"><i class="fab fa-twitter fa-lg mx-4 px-2"></i></a>

              <a href="https://accounts.google.com/v3" class="text-white" target="_blank"><i class="fab fa-google fa-lg"></i></a>

            </div>

              <div class="d-flex justify-content-center text-center mt-4 pt-1">
                <a href="/signup"> Sign up Now</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-k1ssG5wcK0atW5r8fOqDVCahkzMD9o9WZeh8lF2Qh7wKtgJH2
