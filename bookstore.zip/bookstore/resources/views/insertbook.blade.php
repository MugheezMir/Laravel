

<body>

    <legend>PRODUCTS</legend>
<form action="insertbook" method="POST" enctype="multipart/form-data">
    @csrf

    @if (Session::has('success'))
    <div class="alert alert-success">{{ session::get('success') }}</div>

    @endif
    @if (Session::has('failed'))
    <div class="alert alert-s=danger">{{ session::get('failed') }}</div>
@endif
    <div class="form-group">
        <label class="col-md-4 control-label" >Book Id</label>
        <div class="col-md-4">
            <input  name="id" placeholder="Book ID" class="form-control input-md"
                type="text" value="{{ old('id') }}">

        </div>
    </div>
    <div class="form-group">
        <label class="col-md-4 control-label">Book Name</label>
        <div class="col-md-4">
            <input  name="book_name" placeholder="Book Name" class="form-control input-md"
                 type="text" value="{{ old('book_name') }}">

        </div>
    </div>


    <div class="form-group">
        <label class="col-md-4 control-label" >BOOK DESCRIPTION </label>
        <div class="col-md-4">
            <input  name="book_desc" placeholder="Book DESCRIPTION"
                class="form-control input-md" type="text"value="{{ old('book_desc') }}" >

        </div>
    </div>
    <div class="form-group">
        <label class="col-md-4 control-label" >BOOK price </label>
        <div class="col-md-4">
            <input  name="price" placeholder="Book Pricee"
                class="form-control input-md" type="text" value="{{ old('price') }}">

        </div>
    </div>


    <div class="form-group">
        <label class="col-md-4 control-label" >Book CATEGORY</label>
        <div class="col-md-4">
            <select  name="book_cat" class="form-control">
                <option value="Action">Action</option>
                <option value="Horror">Horror</option>
                <option value="Romance">Romance</option>
                <option value="Thriller">Thriller</option>
                <option value="Fantasy">Fantasy</option>
                <option value="Mystery">Mystery</option>

            </select>
        </div>
    </div>




    <div class="form-group">
        <label class="col-md-4 control-label" >Book Author</label>
        <div class="col-md-4">
            <input  name="book_author" placeholder="AUTHOR" class="form-control input-md"
                type="text" value="{{ old('book_author') }}">

        </div>
    </div>

    <div class="form-group">
        <label class="col-md-4 control-label" >image</label>
        <div class="col-md-4">
            <input  name="image" class="input-file" type="file">
        </div>
    </div>



    <div class="form-group">
        <div class="col-md-4">
            <button name="submit" class="btn btn-primary" type="submit">submit</button>
        </div>
    </div>

    </form>

</body>

</html>
