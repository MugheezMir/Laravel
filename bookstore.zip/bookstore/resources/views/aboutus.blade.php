
@include('layout.master')


<div class="container mt-4 " >
    <h1>About Us</h1>
    <hr>
    <div class="row">
      <div class="col-md-6">

        <h3>Our Mission</h3>
        <p>At our bookstore, our mission is to provide our customers with high-quality books at affordable prices. We believe that reading is a powerful tool for personal growth and development, and we want to make it accessible to everyone.</p>
      </div>
      <div class="col-md-6">
        <h3>Our Team</h3>
        <p>Our team is made up of dedicated book enthusiasts who are always on the lookout for the best new reads. We have a wide range of expertise and interests, from classic literature to contemporary fiction, from biographies to cookbooks. Whatever your reading preferences may be, we're here to help you find your next favorite book.</p>
      </div>
    </div>
    <hr>
    <div class="row">
      <div class="col-md-12">
        <h3>Our Services</h3>
        <p>In addition to our extensive collection of books, we offer a range of services to make your reading experience even better. Our online store is open 24/7, so you can browse and purchase books whenever it's convenient for you. We also offer free shipping on all orders over $50.
            If you're not sure what to read next, we offer personalized book recommendations based on your interests and reading history. Our knowledgeable staff is always happy to help you find the perfect book for you.</p>
      </div>
    </div>
  </div>
</div>
@include('layout.footer')



