@include('layout.master')

<div class="header">

    <div class="info" class="fo">
        <br>
        <br>
        <br>
        <br>
        <h2>“I have always imagined that Paradise will be a kind of library.”</h2>
        <div class="meta">
            <h5>Jorge Luis Borges</h5>
        </div>
    </div>
</div>
<section style="background-color: #eee;">
    <div class="text-center container py-5">
        <h4 class="mt-4 mb-5"><strong>Bestsellers</strong></h4>

        <div class="row">
            @foreach ($products as $product)
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card">
                        <div class="bg-image hover-zoom ripple ripple-surface ripple-surface-light"
                            data-mdb-ripple-color="light">
                            <img src="{{ asset('uploads/books/' . $product->image) }}" class="w-100" />
                            <a href="#!">

                                <div class="hover-overlay">
                                    <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                                </div>
                            </a>
                        </div>
                        <div class="card-body">
                            <a href="#" class="text-reset">
                                <h5 class="card-title mb-3">{{ $product->book_name }}</h5>
                            </a>
                            <a href="#" class="text-reset">
                                <p>{{ $product->book_cat }}</p>
                            </a>
                            <h6 class="mb-3">${{ $product->price }}</h6>

        </div>
    </div>
    </div>
    @endforeach
    </div>

    </div>
</section>

{{-- <section style="background-color: #eee;">
    <div class="text-center container py-5">
        <h4 class="mt-4 mb-5"><strong>Bestsellers</strong></h4>

        <div class="row">
            <div class="col-lg-4 col-md-12 mb-4">
                @foreach ($products as $product)
                    <div class="card">
                        <div class="bg-image hover-zoom ripple ripple-surface ripple-surface-light"
                            data-mdb-ripple-color="light">
                            <img src="{{ asset('uploads/books/' . $product->image) }}" class="w-100" />
                            <a href="#!">

                                <a href="#!">

                                    <div class="hover-overlay">
                                        <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                                    </div>
                                </a>
                        </div>
                        <div class="card-body">
                            <a href="" class="text-reset">
                                <h5 class="card-title mb-3">{{ $product->book_name }}</h5>
                            </a>
                            <a href="" class="text-reset">
                                <p>{{ $product->book_cat }}</p>
                            </a>
                            <h6 class="mb-3">${{ $product->price }}</h6>
                        </div>
                @endforeach
            </div>
        </div>

</section> --}}


@include('layout.footer')
