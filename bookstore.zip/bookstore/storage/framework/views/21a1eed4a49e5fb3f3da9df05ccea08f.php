<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css.css">
    <script src="js.js"></script>
    <script src="https://kit.fontawesome.com/522294af6f.js" crossorigin="anonymous"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

</head>

<body>
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle navbar-toggle-sidebar collapsed">
                    MENU
                </button>
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/dashboard">
                    Administrator
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                <ul class="nav navbar-nav navbar-right">
                    <li><a href="allbooks" target="_blank">Visit Site</a></li>
                    <li class="dropdown ">
                        <a href="/auth/adminsportal"  role="button"
                            aria-expanded="false">
                            LogOut

                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
    <div class="container-fluid main-container">
        <div class="col-md-2 sidebar">
            <div class="row">
                <!-- uncomment code for absolute positioning tweek see top comment in css -->
                <div class="absolute-wrapper"> </div>

                <div class="side-menu">
                    <nav class="navbar navbar-default" role="navigation">

                        <div class="side-menu-container">
                            <ul class="nav navbar-nav">
                                <li class="active"><a href="dashboard"><span class="glyphicon glyphicon-dashboard"></span>
                                        Dashboard</a></li>
                                <li><a href="/auth/admin/insert"><span class="glyphicon glyphicon-plane"></span> Insert</a></li>
                                <li><a href="/update"><span class="glyphicon glyphicon-cloud"></span> Update</a></li>
                                <li><a href="/delete"><span class="glyphicon glyphicon-cloud"></span> Delete</a></li>


                            </ul>
                        </div>
                    </nav>

                </div>

            </div>
            <?php if(session()->has('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
        </div>
        <div class="col-md-10">
            <table class="table table-hover" border="1">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Book Name</th>
                        <th scope="col">Book Description</th>
                        <th scope="col">Book Category</th>
                        <th scope="col">Book Author</th>
                        <th scope="col">Book Price</th>
                        <th scope="col">Book Image</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($product->id); ?></th>
                        <td><?php echo e($product->book_name); ?></td>
                        <td><?php echo e($product->book_desc); ?></td>
                        <td><?php echo e($product->book_cat); ?></td>
                        <td><?php echo e($product->book_author); ?></td>
                        <td><?php echo e($product->price); ?></td><img src="<?php echo e(asset('uploads/books/'.$product->image)); ?>" width="100px" height="100px">
                        <td></td>
                        <td>
                            <a href="<?php echo e(url('/update',$product->id)); ?>" class="btn btn-info btn-sm">Update</a>
                            <a href="<?php echo e(url('/delete',$product->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
</body>

</html>
<?php /**PATH C:\Users\HP\OneDrive\Desktop\laraval\project\resources\views/dashboard.blade.php ENDPATH**/ ?>