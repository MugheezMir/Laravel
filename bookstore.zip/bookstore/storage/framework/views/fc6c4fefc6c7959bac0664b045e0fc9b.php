<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div>
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13615.23964550655!2d74.2682316!3d31.4468997!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3919017432b1835b%3A0xe396992a5b05891c!2sUniversity%20of%20Central%20Punjab!5e0!3m2!1sen!2s!4v1681971215292!5m2!1sen!2s"  style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <div class="container contact-form">
        <div class="contact-image">
            <img src="open-book.png" alt="error loading picture"/>
        </div>
        <form action="cinfo" method="POST">
            <h3>Drop Us a Message</h3>
           <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo csrf_field(); ?>
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success"><?php echo e(session::get('success')); ?></div>
                        <?php endif; ?>
                        <?php if(Session::has('failed')): ?>
                        <div class="alert alert-success"><?php echo e(session::get('success')); ?></div>
                        <?php endif; ?>
                        <input type="text" name="name" class="form-control" placeholder="Your Name "value="<?php echo e(old('email')); ?>" >
                        <span style="color:red"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="text" name="email" class="form-control" placeholder="Your Email " value="<?php echo e(old('email')); ?>"  >
                        <span style="color:blue"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="text" name="pnumber" class="form-control" placeholder="Your Phone Number " value="<?php echo e(old('email')); ?>" >
                        <span style="color:red"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="submit" name="submit" class="btnContact" value="Send Message" >
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <textarea name="message" class="form-control" placeholder="Your Message *" style="width: 100%; height: 150px; "value="<?php echo e(old('email')); ?>"></textarea>
                        <span style="color:red"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                </div>
            </div>
        </form>
</div>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\HP\OneDrive\Desktop\laraval\project\resources\views/contactus.blade.php ENDPATH**/ ?>