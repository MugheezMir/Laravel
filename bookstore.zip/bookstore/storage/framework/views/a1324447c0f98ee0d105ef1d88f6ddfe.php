<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="header">

    <div class="info" class="fo">
        <br>
        <br>
        <br>
        <br>
        <h2>“I have always imagined that Paradise will be a kind of library.”</h2>
        <div class="meta">
            <h5>Jorge Luis Borges</h5>
        </div>
    </div>
</div>
<section style="background-color: #eee;">
    <div class="text-center container py-5">
        <h4 class="mt-4 mb-5"><strong>Bestsellers</strong></h4>

        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card">
                        <div class="bg-image hover-zoom ripple ripple-surface ripple-surface-light"
                            data-mdb-ripple-color="light">
                            <img src="<?php echo e(asset('uploads/books/' . $product->image)); ?>" class="w-100" />
                            <a href="#!">

                                <div class="hover-overlay">
                                    <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                                </div>
                            </a>
                        </div>
                        <div class="card-body">
                            <a href="#" class="text-reset">
                                <h5 class="card-title mb-3"><?php echo e($product->book_name); ?></h5>
                            </a>
                            <a href="#" class="text-reset">
                                <p><?php echo e($product->book_cat); ?></p>
                            </a>
                            <h6 class="mb-3">$<?php echo e($product->price); ?></h6>

        </div>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    </div>
</section>




<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\HP\OneDrive\Desktop\laraval\project\resources\views/home.blade.php ENDPATH**/ ?>