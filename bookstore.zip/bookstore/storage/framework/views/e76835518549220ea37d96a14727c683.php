<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><strong>RESET PASSWORD</strong></title>
</head>
<body>
    <h1>Your password is</h1>
    <p>1234567</p>
</body>
</html><?php /**PATH C:\Users\HP\OneDrive\Desktop\laraval\project\resources\views/resetmail.blade.php ENDPATH**/ ?>