<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://kit.fontawesome.com/522294af6f.js" crossorigin="anonymous"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <link rel="stylesheet" href="css.css">
    <title>Forgot Password</title>
</head>
<body>
    <form action="resetpassword" method="POST">
        <?php echo csrf_field(); ?>
    <div class="card text-center" style="width: 300px;">
        <div class="card-header h5 text-white bg-primary">Password Reset</div>
        <div class="card-body px-5">
            <p class="card-text py-2">
                Enter your email address and we'll send you an email with instructions to reset your password.
            </p>
            <?php if(Session::has('failed')): ?>
                        <div class="alert alert-s=danger" style="color:red"><?php echo e(session::get('failed')); ?></div>
                          
                        <?php endif; ?>
                       
                        <?php if(Session::has('email')): ?>
                        <div class="alert alert-s=danger" style="color:green"><?php echo e(session::get('failed')); ?></div>
                          
                        <?php endif; ?>

            <div class="form-outline">
                <input type="email" name="email" class="form-control my-3" />
                <label class="form-label">Email input</label>
            </div>
            <button class="btn btn-primary w-100" type="submit">Reset password</button>
            <div class="d-flex justify-content-between mt-4">
                <a class="btn btn-primary w-10" href="/login">Login</a>
                <a class="btn btn-primary w-10" href="/signup">Register</a>
            </div>
        </div>
    </div>
</form>
    
</body>
</html><?php /**PATH C:\Users\HP\OneDrive\Desktop\laraval\project\resources\views/forgotpassword.blade.php ENDPATH**/ ?>